import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {
    path: 'customers',
    loadChildren: () => import('./customers/customers.module').then(mod => mod.CustomersModule)
  },
  {
    path: 'orders',
    loadChildren: () => import('./orders/orders.module').then(mod => mod.OrdersModule)
  },
  { path: 'reactive-form', 
    loadChildren: () => import('./reactive-form/reactive-form.module').then(m => m.ReactiveFormModule) },

  
  { path: 'login-form', 
    loadChildren: () => import('./login/login.module').then(m => m.LoginModule) 
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  },
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
